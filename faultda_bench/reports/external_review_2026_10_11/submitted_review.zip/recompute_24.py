# 审阅者独立复算：cross_source_v2 全部 24 题
# 不读 faultda_bench/clarity/*，不读 CROSS_SOURCE_REVIEW.md 的参考值。
# 只用 cross_source_v2.json 契约 + 原始 CSV + 自己实现。
import csv, json, os, hashlib
from datetime import datetime
from decimal import Decimal

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
P = json.load(open(os.path.join(BASE, 'faultda_bench/protocols/cross_source_v2.json'), encoding='utf-8'))
TASKS = P['tasks']

def rows_of(rel):
    with open(os.path.join(BASE, rel), newline='', encoding='utf-8') as f:
        return list(csv.DictReader(f))

def sha(rel):
    return hashlib.sha256(open(os.path.join(BASE, rel), 'rb').read()).hexdigest()

print('=' * 100)
print('A. 数据行核对：selection_indices 是否真的取到声明的原始行（value 逐格比对）')
print('=' * 100)
row_ok = {}
for t in TASKS:
    src = rows_of(t['source_path'])
    col = t['contract']['column']
    ok = True; details = []
    for rec in t['versions']['v1']:
        i = int(rec['id'])
        raw = src[i]
        rv = raw[col]
        match = (rv == rec['value'])
        if not match:
            try: match = Decimal(rv) == Decimal(rec['value'])
            except Exception: match = False
        if not match:
            ok = False; details.append(f"id={i} task={rec['value']} raw={rv}")
        # 业务键核对
        kb = t['contract'].get('input_binding', {}).get('key', '')
        if kb in raw and rec['key'] != raw[kb]:
            ok = False; details.append(f"id={i} key task={rec['key']} raw[{kb}]={raw[kb]}")
    row_ok[t['id']] = ok
    idx = t['selection_indices']
    print(f"{t['id']:26s} col={col:14s} indices={str(idx):32s} rows={'OK' if ok else 'MISMATCH: '+ '; '.join(details)}")

print()
print('=' * 100)
print('B. 源文件 sha256 与协议声明一致性')
print('=' * 100)
for rel in sorted({t['source_path'] for t in TASKS}):
    decl = {t['source_sha256'] for t in TASKS if t['source_path'] == rel}
    act = sha(rel)
    print(f"  {rel:44s} declared={list(decl)[0][:16]} actual={act[:16]} {'OK' if decl == {act} else 'MISMATCH'}")

print()
print('=' * 100)
print('C. 业务键/去重契约可执行性')
print('=' * 100)
for t in TASKS:
    dim = t['dimension']
    keys = [d['key'] for d in dim]
    dup_same = len(keys) != len(set(keys))
    # 同键异组？
    m = {}
    conflict = False
    for d in dim:
        if d['key'] in m and m[d['key']] != d['group']: conflict = True
        m[d['key']] = d['group']
    fkeys = {r['key'] for r in t['versions']['v1']}
    covered = fkeys <= set(m)
    orphan = fkeys - set(m)
    binding = t['contract'].get('input_binding', {}).get('key', '(none)')
    print(f"{t['id']:26s} dim行数={len(dim)} 重复键={dup_same} 同键异组={conflict} 覆盖={covered} 未覆盖key={sorted(orphan) if orphan else '无'} key源列={binding}")
    if not covered or conflict:
        print(f"    !! 问题：未覆盖={sorted(orphan)} conflict={conflict}")

print()
print('=' * 100)
print('D. 版本/授权唯一性')
print('=' * 100)
for t in TASKS:
    c = t['contract']
    ver = c['snapshot_version'] if c['version_policy'] == 'snapshot' else t['catalog']['latest']
    same = t['versions']['v1'] == t['versions']['v2']
    print(f"{t['id']:26s} policy={c['version_policy']:9s} authorized={ver} v1==v2={same} "
          f"{'（两版本相同，选错版本也得不到不同答案 -> 版本维度不可考）' if same else ''}")

print()
print('=' * 100)
print('E. 独立复算全部 24 题答案')
print('=' * 100)
results = {}
for t in TASKS:
    c = t['contract']
    ver = c['snapshot_version'] if c['version_policy'] == 'snapshot' else t['catalog']['latest']
    m = {}
    conflict = False
    for d in t['dimension']:
        if d['key'] in m and m[d['key']] != d['group']: conflict = True
        m[d['key']] = d['group']
    buckets = {}
    for r in t['versions'][ver]:
        if r['value'] == '':
            continue
        if c['family'] == 'group':
            g = m.get(r['key'])
            if g is None:
                print(f"  !! {t['id']} 事实 key={r['key']} 在 dimension 中无映射")
                continue
            buckets[g] = buckets.get(g, Decimal(0)) + Decimal(r['value'])
        else:
            buckets['total'] = buckets.get('total', Decimal(0)) + Decimal(r['value'])
    results[t['id']] = {k: float(v) for k, v in buckets.items()}
    extra = ' [同键异组冲突]' if conflict else ''
    print(f"{t['id']:26s} ver={ver} -> {json.dumps(results[t['id']], ensure_ascii=False)}{extra}")

json.dump(results, open(os.path.join(BASE, 'audit', 'my_results_24.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print()
print('我的 24 题结果已存 audit/my_results_24.json')
print('数据行全部一致:', all(row_ok.values()), ' 不一致题:', [k for k, v in row_ok.items() if not v])