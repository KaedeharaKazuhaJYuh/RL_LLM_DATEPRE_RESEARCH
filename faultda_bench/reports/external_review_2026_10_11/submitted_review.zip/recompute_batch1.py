# 审阅者独立复算脚本（第一批 group-01 / window-01 / version-01）
# 原则：不读 faultda_bench/semantic/oracle.py，不参考任何 reference 值。
# 只用：原始 CSV + semantic_tasks_v1.json 里的契约文本 + 自己写的聚合逻辑。
import csv, json, hashlib, os
from datetime import datetime, timezone
from decimal import Decimal

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
P = json.load(open(os.path.join(BASE, 'faultda_bench/protocols/semantic_tasks_v1.json'), encoding='utf-8'))
TASKS = {t['id']: t for t in P['tasks']}

def sha(path):
    return hashlib.sha256(open(path, 'rb').read()).hexdigest()

def rows(path):
    with open(path, newline='', encoding='utf-8') as f:
        return list(csv.DictReader(f))

print('=' * 72)
print('步骤0：包内原始文件完整性 + 声明的 source_sha256 是否一致')
for tid in ('group-01', 'window-01', 'version-01'):
    t = TASKS[tid]
    p = os.path.join(BASE, t['source_path'])
    actual = sha(p)
    print(f"  {tid:11s} {t['source_path']:44s} declared={t['source_sha256'][:16]} actual={actual[:16]} {'OK' if actual==t['source_sha256'] else 'MISMATCH'}")

print()
print('=' * 72)
print('步骤1：抽取 selection 原始行，逐格比对派生值（数据行准确性）')

def check_rows(tid, col, timecol=None):
    t = TASKS[tid]
    rs = rows(os.path.join(BASE, t['source_path']))
    a, b = t['selection']
    sel = rs[a:b]
    print(f"\n--- {tid}  selection=[{a},{b})  column={col}  实际取到 {len(sel)} 行 ---")
    ok = True
    for rec in t['versions']['v1']:
        i = int(rec['id'])
        raw = sel[i]
        raw_v = raw[col]
        match = (raw_v == rec['value'])
        if not match:
            # 允许数值等价（字符串格式差异）
            try:
                match = Decimal(raw_v) == Decimal(rec['value'])
            except Exception:
                match = False
        flag = 'OK ' if match else 'DIFF'
        if not match:
            ok = False
        extra = ''
        if timecol:
            extra = f" raw_time={raw[timecol]!r} task_time={rec.get('time')!r}"
        print(f"  id={rec['id']} key={rec['key']} task_value={rec['value']:>20s} raw_{col}={raw_v:>20s} {flag}{extra}")
    print(f"  => 派生值与原始行{'全部一致' if ok else '存在不一致'}")
    return sel, ok

sel_g, ok_g = check_rows('group-01', 'mpg')
sel_w, ok_w = check_rows('window-01', 'Temperature', timecol='date')
sel_v, ok_v = check_rows('version-01', 'RI')

print()
print('=' * 72)
print('步骤2：业务键 / 去重规则是否可执行（dimension 表）')
for tid in ('group-01', 'window-01', 'version-01'):
    t = TASKS[tid]
    dim = t['dimension']
    print(f"\n--- {tid} dimension 原始 {len(dim)} 条 ---")
    for r in dim:
        print(f"    key={r['key']} group={r['group']}")
    # 契约：identical duplicate key/group mappings count once
    uniq = {}
    conflict = False
    for r in dim:
        k = r['key']
        if k in uniq and uniq[k] != r['group']:
            conflict = True
        uniq[k] = r['group']
    print(f"    去重后映射 = {uniq}；同键异组冲突 = {conflict}")
    used = sorted({r['key'] for r in t['versions']['v1']})
    print(f"    fact 侧出现的 key = {used}；维度覆盖 = {set(uniq)>=set(used)}")

print()
print('=' * 72)
print('步骤3：独立聚合复算（自己实现，不看参考值）')

def num(s):
    return None if s is None or s == '' else float(s)

# ---- group-01：snapshot v1，按业务组求和 ----
t = TASKS['group-01']
assert t['contract']['version_policy'] == 'snapshot'
ver = t['contract']['snapshot_version']
dim = {}
for r in t['dimension']:
    dim[r['key']] = r['group']          # 相同映射覆盖即等价于去重一次
buckets = {}
for rec in t['versions'][ver]:
    g = dim[rec['key']]
    buckets.setdefault(g, Decimal(0))
    buckets[g] += Decimal(rec['value'])   # 每条事实只计一次
print('\n[group-01] snapshot=' + ver)
for g in sorted(buckets):
    print(f'  group {g} = {buckets[g]}')
g01 = {g: float(v) for g, v in buckets.items()}

# 反例：若不去重 dimension（把同一 key 映射算两次），B 组会怎样
print('  反例A（错误做法：按 dimension 行重复累加事实）:')
b2 = {}
for r in t['versions'][ver]:
    for d in t['dimension']:
        if d['key'] == r['key']:
            b2[d['group']] = b2.get(d['group'], Decimal(0)) + Decimal(rec['value'])
print('   ', {k: str(v) for k, v in sorted(b2.items())})
print('  反例B（错误做法：用 latest v2 而非 snapshot v1）:', end=' ')
print('v1==v2 ?', t['versions']['v1'] == t['versions']['v2'])

# ---- window-01：[start,end) 半开区间，按真实时刻 ----
t = TASKS['window-01']
c = t['contract']
s = datetime.fromisoformat(c['start'])
e = datetime.fromisoformat(c['end'])
print(f"\n[window-01] start={c['start']} end={c['end']} closed={c['closed']} analysis={c['analysis']}")
print(f"  contract.output 字段 = {c['output']!r}  <-- 注意与 analysis 文本的措辞是否一致")
ver = c['snapshot_version']
inw, outw, edge = [], [], []
for rec in t['versions'][ver]:
    ts = datetime.fromisoformat(rec['time'])
    if ts.tzinfo is None:
        print('    !! 无时区')
    hit = (s <= ts < e)
    tag = 'IN ' if hit else 'OUT'
    if ts == e or ts == s:
        edge.append((rec['id'], rec['time'], tag, rec['value']))
    (inw if hit else outw).append(rec)
    print(f"    id={rec['id']} time={rec['time']} value={rec['value']:>20s} {tag}")
tot = sum((Decimal(r['value']) for r in inw), Decimal(0))
print(f"  命中行 id = {[r['id'] for r in inw]}")
print(f"  独立复算 total = {tot}  -> float {float(tot)}")
w01 = float(tot)
print('  边界行（与 start/end 恰好相等的行）:')
for i, tm, tag, v in edge:
    print(f"    id={i} time={tm} -> {tag}（半开区间右端排除）value={v}")
alt = tot + Decimal('23.3066666666667')
print(f"  反例（若把右端点当包含）: {alt} -> float {float(alt)}")
print(f"  两者差 = {float(alt) - w01:.14f}")

# ---- version-01：授权快照 v1 全量求和 ----
t = TASKS['version-01']
c = t['contract']
ver = c['snapshot_version']
print(f"\n[version-01] policy={c['version_policy']} authorized={ver} latest={t['catalog']['latest']}")
s1 = sum((Decimal(r['value']) for r in t['versions'][ver] if r['value'] != ''), Decimal(0))
s2 = sum((Decimal(r['value']) for r in t['versions']['v2'] if r['value'] != ''), Decimal(0))
print(f"  v1 求和 = {s1} -> float {float(s1)}")
print(f"  v2 求和 = {s2} -> float {float(s2)}   （差 {float(s2)-float(s1):.6f}）")
v01 = float(s1)
# 差异行定位
for a, b in zip(t['versions']['v1'], t['versions']['v2']):
    if a['value'] != b['value']:
        print(f"  版本差异行 id={a['id']}: v1={a['value']} v2={b['value']}")

print()
print('=' * 72)
print('步骤4：容差判定（用我自己算的值，不看参考）')
TOL = 1e-9
cands = {
    'group-01': {'A': 67, 'B': 60},
    'window-01': {'total': 117.89},
    'version-01': {'total': 12.14083},
}
mine = {'group-01': g01, 'window-01': {'total': w01}, 'version-01': {'total': v01}}
for tid in ('group-01', 'window-01', 'version-01'):
    print(f'\n  {tid}:')
    print(f'    我的独立结果 = {mine[tid]}')
    print(f'    交接文档声称值 = {cands[tid]}')
    for k, cval in cands[tid].items():
        mval = mine[tid][k]
        print(f'    {k}: 差 = {abs(mval-cval):.12g}  容差1e-9 -> {"一致" if abs(mval-cval)<=TOL else "不一致"}')

print()
print('=' * 72)
print('步骤5：version-01 容差反例（12.14043 是否真的不满足）')
print(f'  我的 v1 合计 = {v01!r}')
print(f'  12.14043 与之差 = {abs(v01-12.14043):.12g}  -> {"超出容差(不合格)" if abs(v01-12.14043)>TOL else "在容差内"}')
print(f'  12.14083 与之差 = {abs(v01-12.14083):.12g}')
print(f'  v2 合计 {float(s2)!r} 与 12.14083 之差 = {abs(float(s2)-12.14083):.12g} -> 错误版本是否会被容差放过')