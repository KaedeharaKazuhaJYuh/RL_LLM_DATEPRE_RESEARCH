# 审阅产物说明

**审阅者**：小满（WorkBuddy 独立审阅代理）
**日期**：2026-10-11
**参与关系**：与项目实现无利益关系，未参与任务生成、参考值计算或结果产出。
**审阅对象**：FaultDA 基准，`0.2.15-dev`，实现提交 `75212df`，交接提交 `05cc358`

## 先看哪份

`REVIEW_REPORT_2026-10-11.md` —— 正式审阅记录，含逐题结论、计算证据、需修订项与署名。

## 结论

| 范围 | 通过 | 需修订 | 不通过 | 排除 |
| --- | --- | --- | --- | --- |
| 第一批 3 题 | 3 | 0 | 0 | 0 |
| 第二批 24 题 | 24 | 0 | 0 | 0 |
| 第三批 边界与评分器 | 10 | 1 | 0 | 0 |
| 第四批 科学结论 | 未审 | — | — | 1 |
| **合计** | **37** | **1** | **0** | **1** |

## 文件清单

| 文件 | 内容 |
| --- | --- |
| `REVIEW_REPORT_2026-10-11.md` | 正式审阅记录 |
| `recompute_batch1.py` / `.out.txt` | 第一批 3 题独立复算（group-01 / window-01 / version-01） |
| `recompute_24.py` / `.out.txt` | 24 题独立复算 + 数据行/业务键/版本一致性检查 |
| `boundary_probe.py` / `.out.txt` | 评分器边界反例，41 项断言 |
| `probe_extra.py` / `.out.txt` | 归因与泄漏补充探针（含自造覆盖缺口场景） |
| `my_results_24.json` | 我独立算出的 24 题答案（机读） |

## 复现方式

脚本在原项目根目录下运行（需能 `import faultda_bench`）：

```
python recompute_batch1.py
python recompute_24.py
python boundary_probe.py
python probe_extra.py
```

四个脚本均为本次审阅新写，未复用 `tests/` 下的既有断言。运行时不需要 API 密钥、模型权重或 GPU。

## 唯一需修订项

`semantic_tasks_v1.json` 中 window-01~04、version-01~04 共 8 题的 `contract.output` 写 `"group -> total"`，
但同契约的 analysis 文本与 `semantic/oracle.py:23`、`semantic/compute.py:23` 均规定单键 `total`，
非 group 家族下 `dimension` 表被完全忽略。契约文本自相矛盾。

不影响任何数值判定与评分结果（键集检查按 `{'total'}` 执行），但作为公开分析定义不自洽。
建议按 family 分别措辞后冻结新版本重跑，旧任务与旧结果保留不覆盖。

## 未覆盖范围

- 第四批科学结论（`SCIENTIFIC_GATE_2026_10_11.md`、研究协议 v2）：未审，记为排除。创新性主张不在本次范围内。
- `clarity_v2`、`p0_probe`、`semantic_v1_deepseek` 等报告不在交接审阅范围内，未核对。

## 原始记录

本次审阅未修改任何原始实验记录、协议 JSON 或旧成绩。