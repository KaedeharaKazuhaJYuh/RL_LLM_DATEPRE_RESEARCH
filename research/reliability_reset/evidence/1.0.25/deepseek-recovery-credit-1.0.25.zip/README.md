# DeepSeek 恢复功劳归因实验 1.0.25

先阅读 REPORT.md 和 summary.json；protocol.json 是调用前冻结的配置。
requests.jsonl 保存 41 次真实请求的公开正文、供应商响应正文和用量；不包含授权头或密钥。
runs.json 索引 36 个执行：12 条真实主轨迹、12 个相同前缀的修复分支、12 个规则对照。
executions/ 保存模型/修复器分角色行动、SQLite、输入 CSV 与完整评分。
source_snapshot/ 提供本轮运行源码供对照，在完整项目内复现；TASK_LINEAGE.json 给出已有任务和来源许可记录。
inventory.json 对照上述文件的本地字节。三个任务来自一个历史开发环境。
