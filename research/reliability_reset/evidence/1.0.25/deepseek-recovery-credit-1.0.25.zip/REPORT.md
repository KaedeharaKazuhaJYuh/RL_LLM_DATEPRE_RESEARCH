# DeepSeek 恢复功劳归因：配对前缀实验

尝试主策略单元 12 个；其中 12 个收到模型响应；配对重放 12 个；规则对照 12 个。
API 请求 41 次；按峰值单价的用量估算 $0.010995。

A=真实模型，AH=相同真实前缀接修复器，H=修复器独立；? 表示外部执行原因未能评估。

| 任务 | 条件 | 检查上限 | A/AH/H | 主轨迹请求数 |
| --- | --- | ---: | --- | ---: |
| group-01 | semantic_error | 4 | 111 | 7 |
| version-01 | semantic_error | 1 | 001 | 2 |
| window-01 | semantic_error | 1 | 001 | 2 |
| window-01 | healthy | 4 | 111 | 4 |
| window-01 | semantic_error | 4 | 111 | 6 |
| version-01 | healthy | 1 | 001 | 2 |
| version-01 | semantic_error | 4 | 111 | 6 |
| group-01 | healthy | 1 | 001 | 2 |
| window-01 | healthy | 1 | 001 | 2 |
| group-01 | healthy | 4 | 111 | 3 |
| group-01 | semantic_error | 1 | 001 | 2 |
| version-01 | healthy | 4 | 111 | 3 |

每个模型决策的公开观察哈希均经配对重放核对。真实供应商响应正文、解析失败及请求用量保存在 requests.jsonl。
此开发实验检验归因设计能否描述真实模型行为；重复条件和预算不是独立任务家族。
