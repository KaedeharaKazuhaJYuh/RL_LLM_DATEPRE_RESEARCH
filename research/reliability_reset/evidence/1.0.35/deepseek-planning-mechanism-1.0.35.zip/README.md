# DeepSeek 提示成分与自动规划实验 1.0.35

protocol.json 保存首次请求前冻结的四组提示、接口、任务、预算和代码哈希。
REPORT.md、summary.json、runs.json 给出分层结果和 60 个执行索引。
48 条为真实 DeepSeek 轨迹，12 条为后台共享规则控制，不属于模型采样。
requests.jsonl 保留 155 个实际请求的公开正文、供应商响应正文、用量及解析结果，不含授权头或密钥。
executions/ 保留输入 CSV、SQLite、原始响应、canonical/model-view 双重绑定和完整评分。
source_snapshot/ 是本轮运行源码快照，TASK_LINEAGE.json 记录已有数据来源与许可。
tool-preflight/ 为48次公开读取契约检查，不是模型实验。
OFFLINE_REPLAY_CHECKS.json 记录48条无联网重放及155条响应复核。
FAILURE_LOCATIONS.json 是观察轨迹后的描述性失败定位，非预注册主指标或另一个成功评分。
PLANNER_TIMING.json 是本地规划器微基准，不是模型端到端成本或硬件能耗测量。
inventory.json 校验本包字节，不独立认证历史真实性。
本轮组合提示6/6、预算强调3/6、信息说明2/6、背景0/6；只有一个历史开发环境。
