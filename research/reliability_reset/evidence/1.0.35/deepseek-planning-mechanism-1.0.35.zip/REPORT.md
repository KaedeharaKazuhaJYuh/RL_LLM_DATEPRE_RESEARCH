# 1.0.35：提示成分与自动证据规划

| 阶段 | 接口 | 提示/系统 | 安全完成/解析单元 | inspect 首选 | 输入/输出 tokens |
| --- | --- | --- | ---: | ---: | --- |
| factorial | backend | rule_only | 6/6 | 6/6 | 0/0 |
| factorial | canonical | budget_only | 3/6 | 3/6 | 12392/250 |
| factorial | canonical | combined | 6/6 | 6/6 | 20027/387 |
| factorial | canonical | context | 0/6 | 0/6 | 6430/138 |
| factorial | canonical | relation_only | 2/6 | 6/6 | 22762/465 |
| transfer | backend | rule_only | 6/6 | 6/6 | 0/0 |
| transfer | canonical | auto_plan | 2/6 | 6/6 | 31124/575 |
| transfer | canonical | schema_only | 1/6 | 6/6 | 26417/503 |
| transfer | opaque | auto_plan | 4/6 | 6/6 | 28499/505 |
| transfer | opaque | schema_only | 3/6 | 6/6 | 23937/433 |

所有模型臂均真实采样。rule_only 为每任务/状态共享的后台规则，不是另一批模型采样。
03 实例也曾用于离线开发；这里只有一个环境家族。自动规划建议不会重写模型动作，别名转换不改变工具参数或业务数据。
