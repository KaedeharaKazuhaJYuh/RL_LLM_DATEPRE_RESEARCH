# DeepSeek 预算投影工具接口实验 1.0.55

protocol.json 为首次调用前的设计、相同系统提示、任务、预算及源码哈希。
requests.jsonl 保存公共请求、供应商响应正文、用量和解析分类，不含授权头。
executions/ 保存原始 CSV、SQLite、完整动作、原评分和新增证据支持判断。
REPORT.md、summary.json、runs.json 记录全部54条真实模型轨迹和9个共享规则。
ACTIVATION_AND_ACTIONS.json 单列故障触发、升级、读取拒绝及被排除动作提案。
三臂使用相同提示；feasible_tools 只投影当前工具表及动作枚举，不改模型动作。
OFFLINE_REPLAY_CHECKS.json 记录全部模型和规则重放及响应重新解析，零新增 API。
source_snapshot/ 与 TASK_LINEAGE.json 保存实际运行源码和历史数据血缘。
只有一个环境血缘、三个历史实例；没有训练模型权重或新独立测试集。
inventory.json 检测字节变化，不是外部历史真实性证明。
