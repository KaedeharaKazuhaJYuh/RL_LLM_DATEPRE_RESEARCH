# 1.0.55：预算投影工具接口

| 状态 | 系统 | 完成 | 已触发故障 | 触发后升级 | 超预算读取 | 无证据停止 | 接口外提案 |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| healthy | feasible_tools | 6/6 | 0 | 0 | 0 | 0 | 0 |
| healthy | matched_text | 6/6 | 0 | 0 | 0 | 0 | 0 |
| healthy | rule_only | 3/3 | 0 | 0 | 0 | 0 | 0 |
| healthy | soft_joint | 6/6 | 0 | 0 | 0 | 0 | 0 |
| lost_repair_receipt | feasible_tools | 0/6 | 5 | 5 | 0 | 0 | 0 |
| lost_repair_receipt | matched_text | 0/6 | 6 | 0 | 6 | 0 | 0 |
| lost_repair_receipt | rule_only | 0/3 | 3 | 3 | 0 | 0 | 0 |
| lost_repair_receipt | soft_joint | 0/6 | 6 | 5 | 1 | 0 | 0 |
| semantic_error | feasible_tools | 6/6 | 0 | 0 | 0 | 0 | 0 |
| semantic_error | matched_text | 6/6 | 0 | 0 | 0 | 0 | 0 |
| semantic_error | rule_only | 3/3 | 0 | 0 | 0 | 0 | 0 |
| semantic_error | soft_joint | 6/6 | 0 | 0 | 0 | 0 | 0 |

207 次实际请求；207 次收到响应；峰值未缓存估算 $0.1069206。
升级不计完成；计划但没有实际触发的故障不冒充故障处理。
模型输出被排除动作时原样保留；结构化接口不是约束解码。
