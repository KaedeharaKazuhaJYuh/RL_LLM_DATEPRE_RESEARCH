# DeepSeek 联合控制实验 1.0.50

protocol.json 为首次请求前的固定设计、完成契约、有效任务和源码哈希。
REPORT.md、summary.json、runs.json 记录54条真实模型轨迹和9个共享规则执行。
requests.jsonl 保存181次实际请求和供应商响应正文、用量及解析结果，不含授权头或密钥。
executions/ 包含原始CSV、SQLite、完整原生评分、独立判断和新增公开证据判断。
每次模型调用同时绑定canonical公开观察和实际发送给模型的视图，接口别名不改变参数或业务数据。
ACTIVATION_AND_ACTIONS.json 区分计划故障、实际触发故障和提前升级，保留所有动作序列。
OFFLINE_REPLAY_CHECKS.json 记录54条离线重放、181条响应分类，无新增模型调用。
CONDITIONAL_CAS_PROBE.json 是零模型调用的条件式CAS状态恢复控制，不是模型效果。
source_snapshot/ 和 TASK_LINEAGE.json 给出本轮源码与历史数据来源。
新完成证据契约对所有模型/规则臂相同；原始评分保持完整，不与历史版本直接拼分。
inventory.json 校验本包字节，不独立认证历史不可修改性。
本轮只有三个03历史开发实例和一个环境家族，没有权重训练。
