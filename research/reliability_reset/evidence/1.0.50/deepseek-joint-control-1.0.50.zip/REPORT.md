# 1.0.50：证据、动作与终止联合规划

| 条件 | 接口 | 系统 | 协议完成/解析单元 | 原生完成 | 无证据停止 | 发布后多读失败 |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| healthy | backend | rule_only | 3/3 | 3 | 0 | 0 |
| healthy | canonical | combined | 1/3 | 1 | 0 | 0 |
| healthy | canonical | joint_plan | 3/3 | 3 | 0 | 0 |
| healthy | canonical | read_plan | 1/3 | 1 | 0 | 2 |
| healthy | opaque | combined | 1/3 | 1 | 0 | 0 |
| healthy | opaque | joint_plan | 3/3 | 3 | 0 | 0 |
| healthy | opaque | read_plan | 0/3 | 0 | 0 | 2 |
| lost_repair_receipt | backend | rule_only | 0/3 | 0 | 0 | 0 |
| lost_repair_receipt | canonical | combined | 0/3 | 0 | 0 | 0 |
| lost_repair_receipt | canonical | joint_plan | 0/3 | 0 | 0 | 0 |
| lost_repair_receipt | canonical | read_plan | 0/3 | 0 | 0 | 0 |
| lost_repair_receipt | opaque | combined | 0/3 | 0 | 0 | 0 |
| lost_repair_receipt | opaque | joint_plan | 0/3 | 0 | 0 | 0 |
| lost_repair_receipt | opaque | read_plan | 0/3 | 0 | 0 | 0 |
| semantic_error | backend | rule_only | 3/3 | 3 | 0 | 0 |
| semantic_error | canonical | combined | 1/3 | 1 | 0 | 0 |
| semantic_error | canonical | joint_plan | 3/3 | 3 | 0 | 0 |
| semantic_error | canonical | read_plan | 0/3 | 0 | 0 | 3 |
| semantic_error | opaque | combined | 2/3 | 2 | 0 | 0 |
| semantic_error | opaque | joint_plan | 3/3 | 3 | 0 | 0 |
| semantic_error | opaque | read_plan | 0/3 | 0 | 0 | 3 |

原生评分保持原样。协议完成新增公开证据要求，各臂任务说明相同；不能与旧版本分数直接合并。
回执丢失条件下，实际提交成功不等于模型拥有成功确认。规划器不强制停止，也不替换任何模型提案。
