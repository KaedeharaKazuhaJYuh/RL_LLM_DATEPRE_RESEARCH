# 1.0.30：预算感知工具选择

三个提示臂均为真实模型运行；rule_only 为每个任务/条件共享的一次公开规则执行。

| 提示/规则 | 开发实例层 | 安全完成/已解析单元 | inspect 首选 | 工具响应字节 | 输入/输出 tokens |
| --- | --- | ---: | ---: | ---: | --- |
| budget_guidance | additional_development_instance | 6/6 | 6/6 | 9381 | 18297/355 |
| budget_guidance | prior_live_instance | 6/6 | 6/6 | 9469 | 19858/389 |
| original | additional_development_instance | 0/6 | 0/6 | 276 | 5814/138 |
| original | prior_live_instance | 0/6 | 0/6 | 276 | 5818/138 |
| placebo | additional_development_instance | 1/6 | 1/6 | 2396 | 10460/208 |
| placebo | prior_live_instance | 0/6 | 0/6 | 276 | 6382/138 |
| rule_only | additional_development_instance | 6/6 | 6/6 | 9381 | 0/0 |
| rule_only | prior_live_instance | 6/6 | 6/6 | 9237 | 0/0 |

三种分析意图共享一个历史环境；额外实例不是冻结测试集。长度对照仅匹配 UTF-8 字节，供应商 token 用量单独报告。
配对增益、缺失单元、终止原因及全部轨迹见 summary.json、runs.json 和 executions/。本轮不训练模型权重。
