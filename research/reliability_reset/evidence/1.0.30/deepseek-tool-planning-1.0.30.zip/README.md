# DeepSeek 工具规划干预 1.0.30

protocol.json 为首次请求前冻结的三臂提示、任务、预算和运行源码哈希。
REPORT.md、summary.json、runs.json 分别给出摘要、分层结果和 48 个执行索引。
36 条为真实模型轨迹；12 条为独立公开规则，非模型采样。
requests.jsonl 保存 87 次实际请求、供应商响应正文、用量和解析结果，不含密钥或授权头。
executions/ 保存输入 CSV、SQLite、模型动作、全部原生评分和独立判断。
tool-preflight/ 为另行进行的 12 个离线字段包含关系预检，不属于模型样本。
OFFLINE_REPLAY_CHECKS.json 记录 36 条模型重放和 87 条响应复核，无新增 API 调用。
source_snapshot/ 提供冻结运行源码，TASK_LINEAGE.json 给出已有数据来源及许可。
inventory.json 对照包内字节，不独立认证历史不可修改性。
六个实例均为历史开发数据，只有一个环境家族。原提示 0/12、背景对照 1/12、预算提示 12/12，规则 12/12。
